VNC Viewer for Unix/Linux platforms
===================================

Run the vncinstall script to install VNC Viewer on any UNIX or Linux computer.
See www.realvnc.com for more information.

Usage:
./vncinstall [<binary-dir>] [<doc-dir>]

To specify an alternative location for programs, specify <binary-dir>. To
specify an alternative location for man pages, specify <doc-dir>. Examine
the script for default locations.


Copyright (C) 2002 - 2017 RealVNC Limited. All rights reserved.
